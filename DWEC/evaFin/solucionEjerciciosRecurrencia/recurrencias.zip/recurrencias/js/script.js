
$(function(){

    function sumarHasta(numero) {
        if (numero == 1) {
            return 1
        } else {
            return numero + sumarHasta(numero - 1)
        }
    }

    /*console.log(sumarHasta(1))
    console.log(sumarHasta(3))
    console.log(sumarHasta(5))
    console.log(sumarHasta(0))*/

    function invertirNumero(numero) {
        let numCifras = numero.toString().length
        return invertirNumeroDadoLasCifras(numero, numCifras)
    }

    function invertirNumeroDadoLasCifras(numero, numCifras) {
        //43 / 10 = 4     10*4 + 3
        //43 % 10 = 3
        //478 / 10 = 47

        if (numero < 10) {
            // Si es un numero de una sola cifra, ya está invertido
            return numero;
        } else {
            let ultimoNumero = numero % 10;
            let restoDelNumero =  parseInt(numero / 10);

            return ultimoNumero*Math.pow(10, numCifras - 1) + invertirNumeroDadoLasCifras(restoDelNumero, numCifras - 1)
        }
    }

    //8*10 + 6*10 * 2

    console.log(invertirNumero(3))
    console.log(invertirNumero(43))
    console.log(invertirNumero(268))

    //43 -> 34 = 3*10 + 4
    // 268 -> 862 = 8*100 + 6*10 + 2

    function buscarElemento(array, elemento) {
        if (array.length == 0) {
            return false;
        } else {
            let primerElemento = array[0]
            return primerElemento == elemento || buscarElemento(array.slice(1), elemento)
        }
    }


    let miarray = [ 1, 2, 4, 8]

    console.log(buscarElemento(miarray, 1))
    console.log(buscarElemento(miarray, 4))
    console.log(buscarElemento(miarray, 12))
    
});
