
function Libro(id, titulo, autor) {
  this.id = id;
  this.titulo = titulo;
  this.autor = autor;

  this.prestamo = false;
  this.fechaEntrega = new Date()

  this.cambiarFecha = () => {
    let momentoActual = new Date().getTime() + (7*24*60*60*1000)
    this.fechaEntrega.setTime(momentoActual);
  }
}

let botonAdmin = document.getElementById("entrarAdmin");
let botonEntrar = document.getElementById("entrarCliente")
let contenedorDos = document.getElementById("contenedorDos")

let libros = []
libros.push(new Libro(1, "Quijote", "Cervantes"))
libros.push(new Libro(2, "Marianela", "Galdós"))

botonAdmin.addEventListener("click", seccionAdmin)
botonEntrar.addEventListener("click", seccionUsuario)

function volver() {
  // Volvemos a activar los botones de la página principal
  botonAdmin.disabled = false;
  botonEntrar.disabled = false;

  // Borramos el contenido de contenedorDos
  // Busco los botones y los borro, busco el formulario y lo borro......
  /*let botonAdd = document.getElementById("add")
  botonAdd.remove()
  let botonVolver = document.getElementById("back")
  botonVolver.remove();*/

  // Busco el contenedor padre y borro todo su contenido
  contenedorDos.innerHTML = ""
}

function seccionAdmin() {
  // Deshabilito los botones de la página principal
  botonAdmin.disabled = true;
  botonEntrar.disabled = true;

  crearFormularioAdmin()
  crearBotonesAdmin()
}

function seccionUsuario() {
  // Deshabilito los botones de la página principal
  botonAdmin.disabled = true;
  botonEntrar.disabled = true;

  crearFormularioUsuario()
  crearBotonesUsuario()
}

function crearFormularioAdmin() {
  var formulario = `<form id="formAdmin">
                        <table>
                            <tr>
                                <td><label id="labelTitulo">Titulo:</label></td>
                                <td><input type="text" id="inputTitulo" required></td>
                            </tr>
                            <tr>
                                <td><label id="labelAutor">Autor:</label></td>
                                <td><input type="text" id="inputAutor" required></td>
                            </tr>
                            <tr>
                                <td><label id="labelId">Id:</label></td>
                                <td><input type="number" id="inputId" required value="${libros.length +1}" minvalue="${libros.length +1}" value="${libros.length +1}"></td>
                            </tr>
                        </table>
                      </form>`;

  //contenedorDos.innerHTML = formulario + contenedorDos.innerHTML;
  contenedorDos.innerHTML = formulario;

  let inputsFormulario = buscarInputsAdmin();

  for (clave in inputsFormulario) {
    let input = inputsFormulario[clave]
    input.addEventListener("keyup", validarPorCodigo)

    if (clave == "id") {
      console.log(clave)
      input.addEventListener("change", validarPorCodigo)
    }
    
    //input.addEventListener("keyup", validarPorHtml)
  }

  /*inputsFormulario.id.addEventListener("keyup", validar)
  inputsFormulario.titulo.addEventListener("keyup", validar)
  inputsFormulario.autor.addEventListener("keyup", validar)*/
}

function crearFormularioUsuario() {
  var formulario = `<form id="formUsuario">
                        <table id="tablaUsuario">
                            <tr>
                                <th>Título</th>
                                <th>Autor</th>
                                <th>ID</th>
                                <th>Selección</th>
                            </tr>
                        </table>
                      </form>`;

  contenedorDos.innerHTML = formulario;

  // Creo una fila por cada libro

  /*for (i = 0; i < libros.length; i++) {
  }*/

  for (let libro of libros) {
    // Obtengo la informacion del libro a mostrar
    let titulo = libro.titulo
    let autor = libro.autor
    let id = libro.id

    // Creo una nueva fila
    let fila = document.createElement("tr")

    // Creo td para cada dato que quiero mostrar
    let tdTitulo = document.createElement("td")
    tdTitulo.innerHTML = titulo
    fila.appendChild(tdTitulo)

    let tdAutor = document.createElement("td")
    tdAutor.innerHTML = autor;
    fila.appendChild(tdAutor)

    let tdId = document.createElement("td")
    tdId.append(id);
    fila.appendChild(tdId)

    let tdSeleccion = document.createElement("td")
    let checkbox = document.createElement("input")
    checkbox.type = "checkbox"
    checkbox.addEventListener("change", libroSeleccionado)
    tdSeleccion.appendChild(checkbox)

    fila.appendChild(tdSeleccion)

    // Añado la fila a la tabla
    let tabla = document.getElementsByTagName("table")[0]
    tabla.append(fila)
  }
}

/*function libroSeleccionado() {
  let botonPrestamo = document.getElementById("prestamos")

  let disabled = true;
  let checkboxes = document.getElementsByTagName("input")
  for (let input of checkboxes) {)
    if (input.checked) {
      disabled = false;
    }
  }

  botonPrestamo.disabled = disabled
}*/

function libroSeleccionado() {
  let botonPrestamo = document.getElementById("prestamos")

  let inputsCheckeados = document.querySelectorAll("input[type=checkbox]:checked")

  botonPrestamo.disabled = inputsCheckeados.length <= 0
}

function validarPorCodigo() {
  let inputs = buscarInputsAdmin()
  let botonAdd = document.getElementById("add")

  console.log("validacion")

  if (inputs.id.value != "" &&
      inputs.titulo.value != "" &&
      inputs.autor.value != "" &&
      inputs.id.value == libros.length + 1) {

    botonAdd.disabled = false;
  } else {
    botonAdd.disabled = true;
  }
}

function validarPorHtml() {
  let inputs = buscarInputsAdmin();
  let botonAdd = document.getElementById("add")

  let disabled = false;

  for (clave in inputs) {
    let input = inputs[clave];

    if (!input.checkValidity()) {
      disabled = true;
    }
  }

  botonAdd.disabled = disabled;
}

function crearBotonesAdmin() {
  let botonAdd = crearBoton("add", "Añadir", true)
  let botonVolver = crearBoton("back", "Volver", false)

  botonVolver.addEventListener("click", volver)
  botonAdd.addEventListener("click", addLibroYBorrar)

  contenedorDos.append(botonAdd)
  contenedorDos.append(botonVolver)
}

function crearBotonesUsuario() {
  let botonPrestamos = crearBoton("prestamos", "Préstamo libros", true)
  let botonVolver = crearBoton("back", "Volver", false)

  botonVolver.addEventListener("click", volver)
  botonPrestamos.addEventListener("click", prestarLibros)

  contenedorDos.append(botonPrestamos)
  contenedorDos.append(botonVolver)
}

function buscarInputsAdmin() {
  let inputId = document.getElementById("inputId")
  let inputTitulo = document.getElementById("inputTitulo")
  let inputAutor = document.getElementById("inputAutor")

  return {
    id: inputId,
    titulo: inputTitulo,
    autor: inputAutor
  }
}

function prestarLibros() {
  // Busco los libros seleccionados
  let filas = document.getElementsByTagName("tr")

  let contador = 0;
  //for (i = 0; i < filas.length; i++) {
  for (let fila of filas) {
    // Nos saltamos la fila del encabezado
    if (fila != filas [0]) {
      // let otroCheckbox = fila.childNodes[3].childNodes[0];

      let celdas = fila.getElementsByTagName("td")
      let tdConCheckbox = celdas[3]
      let checkbox = tdConCheckbox.getElementsByTagName("input")[0]

      if (checkbox.checked) {
        // Sé que el libro representado por esta fila ha sido
        // seleccionado para préstamos
        console.log(contador)
        let libroSeleccionado = libros[contador]

        if (!libroSeleccionado.prestamo) {
          libroSeleccionado.cambiarFecha()

          let fechaEntrega = libroSeleccionado.fechaEntrega
          alert("La fecha de entrega del libro " + libroSeleccionado.titulo + " es: " + fechaEntrega)

          // Guardar la cookie para este libro
          setCookie(libroSeleccionado.id, fechaEntrega)

          let cookiePedida = getCookie(libroSeleccionado.id)
          console.log(cookiePedida)

          libroSeleccionado.prestamo = true
        } else {
          alert("El libro " + libroSeleccionado.titulo + " ya está prestado")
        }
      }

      contador++; // contador = contador + 1
    }

    // Esto implica que tendríamos que hacer libros[contador -1]
    //contador++; // contador = contador + 1
  }
}

function addLibroYBorrar() {
  addLibro()
  let inputs = buscarInputsAdmin()

  //inputs.id.value = libros.length + 1;
  inputs.id.value = "";
  inputs.autor.value = ""
  inputs.titulo.value = ""

  let botonAdd = document.getElementById("add")
  botonAdd.disabled = true;
}

function addLibro() {
  // Busco los elementos que contienen la información
  let inputs = buscarInputsAdmin()

  // Obtengo la información de los elementos
  let id = inputs.id.value;
  let titulo = inputs.titulo.value;
  let autor = inputs.autor.value;

  // Creo un nuevo libro
  let nuevoLibro = new Libro(id, titulo, autor)

  // Lo meto en el array de libros
  libros.push(nuevoLibro)
}

function crearBoton(id, value, disabled) {
  let nuevoBoton = document.createElement("button");
  
  nuevoBoton.id = id
  nuevoBoton.textContent = value
  nuevoBoton.disabled = disabled;

  return nuevoBoton;
}
