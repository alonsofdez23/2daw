
$(function() {


    function Concesionario(marca, numCoches, vendedores) {
        this.marca = marca;
        this.numCoches = numCoches;
        
        let vendedoresAux = []
        for (vendedor of vendedores) {
            vendedoresAux.push(new Vendedor(vendedor.nombre, vendedor.telefono))
        }

        this.vendedores = vendedoresAux
        this.vendedores[1].nombre
    }

    function Vendedor(nombre, telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }

    let vendedores1 = [
        new Vendedor("Pepe", "666123456"),
        new Vendedor("Paco", "82345678"),
        new Vendedor("Adrian", "956")
    ]
    console.log(vendedores1[1].nombre)

    let concesarionario1 = new Concesionario("Peugeot", 32, vendedores1)

    console.log(vendedores1[1].nombre)
    
    let vendedores2 = [
        new Vendedor("Joaquin", "866123456"),
        new Vendedor("Enrique", "92345678"),
        new Vendedor("Evaristo", "656")
    ]
    
    let vendedores3 = [
        new Vendedor("Marina", "966123456"),
        new Vendedor("Laura", "62345678"),
        new Vendedor("pepe", "856")
    ]

    let concesarionario2 = new Concesionario("citroen", 12, vendedores2)
    let concesarionario3 = new Concesionario("peugeot", 48, vendedores3)
    let concesarionario4 = new Concesionario("kia", 52, vendedores3)

    let concesionarios = [ concesarionario1, concesarionario2, concesarionario3]

    concesarionariosPeugeot = () => {
        let contador = 0

        for (concesionario of concesionarios) {
            if (concesionario.marca == "peugeot") {
                contador++;
            }
        }

        return contador
    }

    concesarionariosPeugeotAvanzada = () => {
        return concesionarios.filter(concesionario => concesionario.marca.toLowerCase() == "peugeot").length
    }

    console.log(concesarionariosPeugeotAvanzada())

    concesarionariosGrandes = () => {
        let contador = 0

        for (concesionario of concesionarios) {
            if (concesionario.numCoches >= 40) {
                contador++;
            }
        }

        return contador
    }

    console.log(concesarionariosGrandes())

    vendedoresLlamadosPepe = () => {
        let contador = 0

        for (concesionario of concesionarios) {
            for (vendedor of concesionario.vendedores) {
                if (vendedor.nombre.toLowerCase() == "pepe") {
                    contador++;
                }
            }
        }

        return contador
    }

    console.log(vendedoresLlamadosPepe())

    listadoTelefonos = () => {
        let telefonos = []

        for (concesionario of concesionarios) {
            for (vendedor of concesionario.vendedores) {
                telefonos.push(vendedor.telefono)
            }
        }

        telefonos.sort((telefono1, telefono2) => {
            let primeroNumero1 = telefono1.substr(0, 1)
            let primeroNumero2 = telefono2.substr(0, 1)

            if (primeroNumero1 == "6") {
                if (primeroNumero2 == "6") {
                    let restoNumero1 = telefono1.substr(1, telefono1.length - 1)
                    let restoNumero2 = telefono2.substr(1, telefono2.length - 1)

                    return restoNumero1.localeCompare(restoNumero2);
                } else {
                    return -1
                }
            } else if (primeroNumero1 == "8") {
                if (primeroNumero2 == "8") {
                    return 0
                } else {
                    return 1
                }
            }  else if (primeroNumero1 == "9") {
                if (primeroNumero2 == "9") {
                    return 0
                } else if (primeroNumero2 == "8") {
                    return -1
                } else {
                    return 1
                }
            }
        })

        return telefonos
    }

    console.log(listadoTelefonos())

    cambiarAsignaciones = (nuevoConcesario) => {
        let nuevosConcesionarios = []

        // Copio el array con la excepción del elemento que queremos evitar
        for (numConcesionario in concesionarios) {
            if (numConcesionario != 2) {
                nuevosConcesionarios.push(concesionarios[numConcesionario])
            }
        }

        // Me asigno el nuevo array
        nuevosConcesionarios.push(nuevoConcesario)

        concesionarios = nuevosConcesionarios
    }

    cambiarAsignacionesSinCopiaAuxiliar = (nuevoConcesario) => {
        concesionarios.pop(concesionarios[2])
        concesionarios.push(nuevoConcesario)
    }


    //cambiarAsignaciones(concesarionario4)
    cambiarAsignacionesSinCopiaAuxiliar(concesarionario4)

    console.log(concesionarios)
});
