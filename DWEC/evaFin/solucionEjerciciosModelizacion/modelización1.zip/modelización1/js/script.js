
$(function(){

    let bola1 = {
        identificador: 1,
        marca: "Dunlop",
        color: "verde",
        usada: false
    }

    let bola2 = {
        identificador: 2,
        marca: "Dunlop",
        color: "rojo",
        usada: false
    }

    let bola3 = {
        identificador: 3,
        marca: "Artengo",
        color: "azul",
        usada: false 
    }

    let bola4 = {
        identificador: 4,
        marca: "Artengo",
        color: "rojo",
        usada: true 
    }

    let bola5 = {
        identificador: 5,
        marca: "Bullpadel",
        color: "verde",
        usada: true
    }

    let c1 = {
        cuidador: "Adrian",
        bolas: []
    }

    let c2 = {
        cuidador: "Joaquin",
        bolas: []
    }

    let c3 = {
        cuidador: "Enrique",
        bolas: []
    }

    let carros = {
        verde: c1,
        rojo: c2,
        azul: c3
    }

    c1["bolas"].push(bola1)
    c1["bolas"].push(bola5)
    //carroVerde.bolas.push(bola1)
    c2["bolas"].push(bola3)
    c2["bolas"].push(bola4)

    c3["bolas"].push(bola2)

    function cuidadorBolasRojas() {
        return carros.rojo.cuidador
    }

    cuidadorBolasRojas()

    function listarCarrosPorA() {
        let listaCarros = []

        for (carro in carros) {
            let carroAuxiliar = carros[carro]
            if(carroAuxiliar.cuidador.startsWith("C")) {
                //console.log(carroAuxiliar.cuidador)
                listaCarros.push(carroAuxiliar)
            }
        }

        return listaCarros
    }

    console.log(listarCarrosPorA())

    function cantidadRojas() {
        return carros.rojo.bolas.length
    }

    console.log(cantidadRojas())

    function bolasVerdesUsadas() {
        let bolasVerdes = carros.verde.bolas
        let contador = 0

        for (bolaVerde of bolasVerdes) {
            if (bolaVerde.usada) {
                contador++
            }
        }

        return contador
    }

    console.log(bolasVerdesUsadas())

    function bolasVerdesUsadasAvanzada() {
        let bolasVerdes = carros.verde.bolas
        return bolasVerdes.filter((bola) => bola.usada ).length
    }

    console.log(bolasVerdesUsadasAvanzada())

    function bolasUsadasAvanzada(carro) {
        let bolas = carro.bolas
        return bolas.filter((bola) => bola.usada ).length
    }


    function bolasUsadasTodosLosCarros() {
        //return bolasUsadasAvanzada("verde") + bolasUsadasAvanzada("rojo") + bolasUsadasAvanzada("azul")
        let contador = 0
        
        for(carro in carros) {
            contador += bolasUsadasAvanzada(carros[carro])
        }

        return contador
    }

    console.log(bolasUsadasTodosLosCarros())

    function bolasUsadasTodosLosCarrosAvanzada() {
    
        /*let arrayDeCarros = []
        
        for(carro in carros) {
            arrayDeCarros.push(carros[carro])
        } */

        let arrayUsadas = Object.values(carros).map((carro) => bolasUsadasAvanzada(carro))

        let suma = 0

        for(usada of arrayUsadas) {
            suma += usada
        }

        return suma

    }

    console.log(bolasUsadasTodosLosCarrosAvanzada())

    function vaciarCarros() {
        // Para cada carro, lo vacíamos
        for (carro in carros) {
            carros[carro].bolas = []
        }
        
    }

    vaciarCarros();
    console.log(bolasUsadasTodosLosCarrosAvanzada())

    function repartirBolasNuevas(bolasNuevas) {
        for (bola of bolasNuevas) {
            carros[bola.color].bolas.push(bola)
            
            /*if (bola.color == "rojo") {
                carros.rojo.bolas.push(bola)
            } else if (bola.color == "azul") {
                carros.azul.bolas.push(bola)
            } else if (bola.color == "verde") {
                carros.verde.bolas.push(bola)
            } else {
                // No nos van a dar bolas innovadoras
            }*/

            /*switch (bola.color) {
                case "rojo":
                    carros.rojo.bolas.push(bola)
                    break;
                case "azul":
                    carros.azul.bolas.push(bola)
                    break;
                case "verde":
                    carros.verde.bolas.push(bola)
            }*/
        }
    }

    repartirBolasNuevas(
        [
            {
                identificador: 1,
                marca: "Dunlop",
                color: "verde",
                usada: false
            },
            {
                identificador: 2,
                marca: "Dunlop",
                color: "verde",
                usada: true
            },
            {
                identificador: 3,
                marca: "Dunlop",
                color: "azul",
                usada: false
            },
            {
                identificador: 4,
                marca: "Dunlop",
                color: "rojo",
                usada: false
            }
        ]
    );

    console.log(bolasUsadasTodosLosCarrosAvanzada())
    
});
