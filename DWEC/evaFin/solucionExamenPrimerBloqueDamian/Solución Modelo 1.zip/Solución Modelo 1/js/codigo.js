
var c2=document.getElementById("contenedorDos");
var botonAdmin = document.getElementById("entrarAdmin");
var botonCliente = document.getElementById("entrarCliente");
var productos=[];

//APARTADO A
//
function Producto(nombre, precio, stock) {
    this.nombre = nombre;
    this.precio = precio;
    this.stock = stock;
    this.cambiarStock = function () {
        this.stock = this.stock - 1;
    }
}

productos.push(new Producto("Langostinos", "20","3"));
productos.push(new Producto("Manzanilla", "10","3"));

//APARTADO B
//
botonAdmin.addEventListener("click", seccionAdmin);

function seccionAdmin(){

    //Se crea tabla con HTML desde JS
    //
    crearTablaAdmin();
        
    //Se añaden botones con métodos DOM
    //
    var botonAnadir = document.createElement("button");
    botonAnadir.textContent = "Añadir";
    botonAnadir.id = "botonAnadir";
    botonAnadir.disabled = "true";

    c2.appendChild(botonAnadir);

    var botonVolver = document.createElement("button");
    botonVolver.textContent = "Volver";
    botonVolver.id = "botonVolver";
    c2.appendChild(botonVolver);

    botonAdmin.disabled = true;
    botonCliente.disabled = true;

    //Se añaden EVENTOS a botones e inputs
    //
    var formAdmin=document.getElementById("formAdmin");
    var inputs = formAdmin.getElementsByTagName("input");
        
    for (let i=0; i<inputs.length;i++){
        inputs[i].addEventListener("blur", validar);
    }

    //APARTADO D
    //
    function validar() {
        if (inputs[0].checkValidity()&&inputs[1].checkValidity()&&inputs[2].checkValidity()){
            botonAnadir.disabled = false;
        } else {
            botonAnadir.disabled = true;
            this.reportValidity();
        }
    }
  
    botonAnadir.addEventListener("click", anadirProducto);
    botonVolver.addEventListener("click", volver);
}

function crearTablaAdmin(){
    var formulario = `<form id="formAdmin">
                        <table>
                            <tr>
                                <td><label id="labelNombre">Nombre:</label></td>
                                <td><input type="text" id="inputNombre" required></td>
                            </tr>
                            <tr>
                                <td><label id="labelPrecio">Precio:</label></td>
                                <td><input type="text" id="inputPrecio" pattern="[0-9]+\\.[0-9]{2}" required></td>
                            </tr>
                            <tr>
                                <td><label id="labelStock">Stock:</label></td>
                                <td><input type="number" id="inputStock" required></td>
                            </tr>
                        </table>`;
    c2.innerHTML+=formulario;
}
//APARTADO C
//
function anadirProducto(){
    let prod =new Producto(inputNombre.value, inputPrecio.value, inputStock.value);
    productos.push(prod);
}

function volver(){
    botonAdmin.disabled = false;
    botonCliente.disabled = false;
    c2.innerHTML="";

}

botonCliente.addEventListener("click", seccionCliente);

//APARTADO E
//
function seccionCliente(){

    var formularioCliente = `<form id ="formCliente">
                            <table id="tablaCliente" style="text-align: center">
                                <tr>
                                    <th>NOMBRE</th>
                                    <th>PRECIO</th>
                                    <th>STOCK</th>
                                    <th>SELECCIÓN</th>
                                </tr>
                            </table>
                        </form>`;
    c2.innerHTML+=formularioCliente;

    for (let i=0; i<productos.length;i++){
        
        let fila = document.createElement("tr");

        for (prop in (productos[i])){
            if ((typeof(productos[i][prop]) != "function")){
            //  if (!String(productos[i][prop]).includes("function")){
                let celda = document.createElement("td");
                celda.innerHTML=productos[i][prop];
                fila.appendChild(celda);
            }
        }
        let celda = document.createElement("td");
        let check =document.createElement("input");
        check.setAttribute("type", "checkbox");
        celda.appendChild(check);
        fila.appendChild(celda);
            
        tablaCliente.appendChild(fila);  

    }      

    var botonComprar = document.createElement("button");
    botonComprar.textContent = "Comprar";
    botonComprar.id = "botonComprar";
    botonComprar.disabled = "true";
    c2.appendChild(botonComprar);

    var botonVolverDos = document.createElement("button");
    botonVolverDos.textContent = "Volver";
    botonVolverDos.id = "botonVolverDos";
    c2.appendChild(botonVolverDos);

    botonAdmin.disabled = "true";
    botonCliente.disabled = "true";

    var formCliente=document.getElementById("formCliente");
    var inputsCliente =formCliente.querySelectorAll("input[type=checkbox]");
            
    for (let i=0; i<inputsCliente.length;i++){
        inputsCliente[i].addEventListener("change", validarCliente);
    }

   //APARTADO F
   //
    function validarCliente() {
       
        if (formCliente.querySelectorAll("input[type=checkbox]:checked").length>0){
            botonComprar.disabled = false;
        } else {
            botonComprar.disabled = true;
        }
    }

    botonComprar.addEventListener("click", comprar);
    botonVolverDos.addEventListener("click", volver);

    function comprar(){
        var suma =0;    
        var filas = document.getElementsByTagName("tr");
       
        for (let i=1; i<filas.length; i++){
           
            if (filas[i].childNodes[3].childNodes[0].checked){ 

                //APARTADO G
                for (j=0; j<productos.length; j++){
                        if (productos[j].nombre==filas[i].childNodes[0].childNodes[0].textContent){
                        productos[j].cambiarStock(); 
                    }
                } 
                
                //APARTADO H
                suma += parseFloat(filas[i].childNodes[1].childNodes[0].nodeValue);
                
                //APARTADO I
                setCookie(filas[i].childNodes[0].childNodes[0].textContent, filas[i].childNodes[1].childNodes[0].nodeValue, 1);
            }
         }

        var total = document.createElement("p");
        total.innerHTML=`El precio total es ${parseFloat(suma)} euros`;
        c2.appendChild(total);
    }
}