
var c2=document.getElementById("contenedorDos");
var botonAdmin = document.getElementById("entrarAdmin");
var botonUsuario = document.getElementById("entrarUsuario");
var catalogo = [];

//APARTADO A
//
function Libro (titulo, autor, id) {
    this.titulo = titulo;
    this.autor = autor;
    this.id = id;
    this.prestado = false;
    this.fechaEntrega=new Date();
    this.cambiarFechaentrega = function () {
        let ahora = new Date();
        this.fechaEntrega.setTime(ahora.getTime() + (7*(1000*60*60*24))) ;
    }
}

catalogo.push(new Libro("Quijote", "Cervantes","1"));
catalogo.push(new Libro("Platero", "JuanRa","2"));

//APARTADO B
//
botonAdmin.addEventListener("click", seccionAdmin);

function seccionAdmin(){

    //Se crea tabla con HTML desde JS
    //
    crearTablaAdmin();
        
    //Se añaden botones con métodos DOM
    //
    var botonAnadir = document.createElement("button");
    botonAnadir.textContent = "Añadir";
    botonAnadir.id = "botonAnadir";
    botonAnadir.disabled = "true";

    c2.appendChild(botonAnadir);

    var botonVolver = document.createElement("button");
    botonVolver.textContent = "Volver";
    botonVolver.id = "botonVolver";
    c2.appendChild(botonVolver);

    botonAdmin.disabled = true;
    botonUsuario.disabled = true;

    //Se añaden EVENTOS a botones e inputs
    //
    var formAdmin=document.getElementById("formAdmin");
    var inputs = formAdmin.getElementsByTagName("input");
        
    for (let i=0; i<inputs.length;i++){
        inputs[i].addEventListener("blur", validar);
    }

    //APARTADO D
    //
    function validar() {
        if (inputs[0].checkValidity()&&inputs[1].checkValidity()&&inputs[2].checkValidity()){
            botonAnadir.disabled = false;
        } else {
            botonAnadir.disabled = true;
            this.reportValidity();
        }
    }
  
    botonAnadir.addEventListener("click", anadirLibro);
    botonVolver.addEventListener("click", volver);
}

function crearTablaAdmin(){
    var formulario = `<form id="formAdmin">
                        <table>
                            <tr>
                                <td><label id="labelTitulo">Titulo:</label></td>
                                <td><input type="text" id="inputTitulo" required></td>
                            </tr>
                            <tr>
                                <td><label id="labelAutor">Autor:</label></td>
                                <td><input type="text" id="inputAutor" required></td>
                            </tr>
                            <tr>
                                <td><label id="labelId">Id:</label></td>
                                <td><input type="number" id="inputId" value= ${catalogo.length+1} required></td>
                            </tr>
                        </table>`;
    c2.innerHTML+=formulario;
}
//APARTADO C
//
function anadirLibro(){
    let libro =new Libro(inputTitulo.value, inputAutor.value, inputId.value);
    catalogo.push(libro);
}

function volver(){
    botonAdmin.disabled = false;
    botonUsuario.disabled = false;
    c2.innerHTML="";
}

botonUsuario.addEventListener("click", seccionUsuario);

//APARTADO E
//
function seccionUsuario(){

    var formularioUsuario = `<form id ="formUsuario">
                            <table id="tablaUsuario" style="text-align: center">
                                <tr>
                                    <th>Titulo</th>
                                    <th>Autor</th>
                                    <th>Id</th>
                                    <th>Selección</th>
                                </tr>
                            </table>
                        </form>`;
    c2.innerHTML+=formularioUsuario;

    for (let i=0; i<catalogo.length;i++){
        
        let fila = document.createElement("tr");
        let contador = 0;
        for (prop in (catalogo[i])){
            if ((typeof(catalogo[i][prop]) != "function")&& contador<3){
            //  if (!String(catalogo[i][prop]).includes("function")){
                let celda = document.createElement("td");
                celda.innerHTML=catalogo[i][prop];
                fila.appendChild(celda);
                contador++;
            }
        }
        let celda = document.createElement("td");
        let check =document.createElement("input");
        check.setAttribute("type", "checkbox");
        celda.appendChild(check);
        fila.appendChild(celda);
            
        tablaUsuario.appendChild(fila);  

    }      

    var botonPrestamo = document.createElement("button");
    botonPrestamo.textContent = "Préstamo Libro";
    botonPrestamo.id = "botonPrestamo";
    botonPrestamo.disabled = "true";
    c2.appendChild(botonPrestamo);

    var botonVolverDos = document.createElement("button");
    botonVolverDos.textContent = "Volver";
    botonVolverDos.id = "botonVolverDos";
    c2.appendChild(botonVolverDos);

    botonAdmin.disabled = "true";
    botonUsuario.disabled = "true";

    var formUsuario = document.getElementById("formUsuario");
    var inputsUsuario = formUsuario.querySelectorAll("input[type=checkbox]");
            
    for (let i=0; i<inputsUsuario.length;i++){
        inputsUsuario[i].addEventListener("change", validarUsuario);
    }

   //APARTADO F
   //
    function validarUsuario() {
       
        if (formUsuario.querySelectorAll("input[type=checkbox]:checked").length>0){
            botonPrestamo.disabled = false;
        } else {
            botonPrestamo.disabled = true;
        }
    }

    botonPrestamo.addEventListener("click", prestamo);
    botonVolverDos.addEventListener("click", volver);

    function prestamo(){
        
        var filas = document.getElementsByTagName("tr");
       
        for (let i=1; i<filas.length; i++){
           
            if (filas[i].childNodes[3].childNodes[0].checked){ 

                //APARTADO G
                for (j=0; j<catalogo.length; j++){
                        if (catalogo[j].titulo==filas[i].childNodes[0].childNodes[0].textContent){
                          if(!catalogo[j].prestamo){
                            catalogo[j].cambiarFechaentrega();
                            catalogo[j].prestamo=true;
                            //APARTADO H
                            let mensaje = document.createElement("p");
                            mensaje.innerHTML=`El libro ${catalogo[j].titulo} se debe entregar: ${catalogo[j].fechaEntrega.toLocaleDateString()}`;
                            c2.appendChild(mensaje);
                            //APARTADO I
                            setCookie(filas[i].childNodes[2].childNodes[0].textContent, catalogo[j].fechaEntrega.toLocaleDateString(), 1);
                            }else {alert("Libro ya prestado");
                        }
                    }
                } 
                
                               
                
            }
         }

       
    }
}